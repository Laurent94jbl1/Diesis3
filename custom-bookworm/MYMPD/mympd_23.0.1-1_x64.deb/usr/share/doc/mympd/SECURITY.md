# Security Policy

## Supported Versions

| VERSION | SUPPORTED |
| ------- | --------- |
| Latest Release | :white_check_mark: |

## Reporting a Vulnerability

Please write a mail to: <mail@jcgames.de>. I will respond as fast as possible.

#ifndef _NET_PPP_DEFS_H
#define _NET_PPP_DEFS_H 1

#include <bits/types/time_t.h>
#include <asm/types.h>
#include <linux/ppp_defs.h>

#endif /* net/ppp_defs.h */
